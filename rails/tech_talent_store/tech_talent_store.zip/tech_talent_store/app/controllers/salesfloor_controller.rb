class SalesfloorController < ApplicationController
  def welcome
  	@products = Product.all
  end

  def tts_laptops
  	@products = Product.all
  end

  def tts_clothing
  	@products = Product.all
  end

  def tts_books
  	@products = Product.all
  end
end
