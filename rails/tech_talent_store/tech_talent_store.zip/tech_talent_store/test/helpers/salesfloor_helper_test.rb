require 'test_helper'

class SalesfloorHelperTest < ActionView::TestCase
end
